<?php
function register_my_menus() {
    register_nav_menus( array(
        'primary' => __( 'Primary Menu' ),
        'header-button' => __( 'Header Button' ),
    ));
}
add_action( 'after_setup_theme', 'register_my_menus' );

function tawazun_theme_scripts() {
    wp_enqueue_style('style', get_template_directory_uri() . '/assets/css/styles.css');
    wp_enqueue_style('slick-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css', array(), null);
    wp_enqueue_style('slick-theme-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css', array(), null);
    wp_enqueue_script('jquery');
    wp_enqueue_script('slick-scripts', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js');
}

add_action('wp_enqueue_scripts', 'tawazun_theme_scripts');


// Register Custom Post Type for Logo Slider
function create_logo_slider_cpt() {
    $labels = array(
        'name' => 'Logo Sliders',
        'singular_name' => 'Logo Slider',
        'add_new' => 'Add New Logo',
        'add_new_item' => 'Add New Logo',
        'edit_item' => 'Edit Logo',
        'view_item' => 'View Logo',
        'all_items' => 'All Logos',
        'menu_name' => 'Logo Slider',
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-images-alt2',
        'supports' => array('title', 'thumbnail', 'editor'),
        'has_archive' => true,
        'rewrite' => array('slug' => 'Logos'),
    );

    register_post_type('logo_slider', $args);
}
add_action('init', 'create_logo_slider_cpt');
