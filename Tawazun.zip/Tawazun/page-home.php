<?php
/*
  Template Name: Home
*/

?>
<?php get_header(); ?>
<section id="main">
  <section class="hero">
  <?php
      $background_image = get_field('background_image'); 
      if ($background_image) :
          $background_image = $background_image['url']; 
      endif ?>
    <div class="hero__wrapper" style="background-image: url('<?php echo esc_url($background_image); ?>');">
      <div class="hero__content">
        <div class="hero__content--text">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero/frame1.png" alt="Frame" />
          <h1><?php echo get_field('heading'); ?></h1>
          <p>
            <?php echo get_field('description'); ?>
          </p>
          <ul class="hero__btns">
            <li class="hero__btns--services">
                <button class="toggle-menu">
                  <span></span>
                  <span></span>
                  <span></span>                      
                </button>
                <?php 
                  $transparent_button = get_field('transparent_button');
                  if ($transparent_button) {
                      echo '<a href="' . esc_url($transparent_button['url']) . '" target="' . esc_attr($transparent_button['target']) . '">' . esc_html($transparent_button['title']) . '</a>';
                  }
                ?>
              </li>
              <li>
                <?php
                  $colored_button     = get_field('colored_button_1');
                  if ($colored_button) {
                      echo '<a href="' . esc_url($colored_button['url']) . '" target="' . esc_attr($colored_button['target']) . '">' . esc_html($colored_button['title']) . '</a>';
                  }
                  ?>
              </li>
          </ul>
          <ul class="hero__social-icons">
            <li>
              <?php 
                $social_icon_1          = get_field('social_icon_1');
                $social_icon_link_1     = get_field('social_icon_link_1');                
              ?>
              <a target="_blank" href="<?php echo esc_attr( get_field('social_icon_link_1') ); ?>">
                <?php
                if( !empty( $social_icon_1 ) ): ?>
                  <img src="<?php echo esc_url($social_icon_1['url']); ?>" alt="<?php echo esc_attr($social_icon_1['alt']); ?>" />
                <?php endif; ?>
              </a>
            </li>
            <li>
              <?php 
                $social_icon_2          = get_field('social_icon_2');
                $social_icon_link_2     = get_field('social_icon_link_2');                
              ?>
              <a target="_blank" href="<?php echo esc_attr( get_field('social_icon_link_1') ); ?>">
                <?php
                if( !empty( $social_icon_2 ) ): ?>
                  <img src="<?php echo esc_url($social_icon_2['url']); ?>" alt="<?php echo esc_attr($social_icon_2['alt']); ?>" />
                <?php endif; ?>
              </a>
            </li>
            <li>
              <?php 
                $social_icon_3          = get_field('social_icon_3');
                $social_icon_link_3     = get_field('social_icon_link_3');                
              ?>
              <a target="_blank" href="<?php echo esc_attr( get_field('social_icon_link_1') ); ?>">
                <?php
                if( !empty( $social_icon_3 ) ): ?>
                  <img src="<?php echo esc_url($social_icon_3['url']); ?>" alt="<?php echo esc_attr($social_icon_3['alt']); ?>" />
                <?php endif; ?>
              </a>
            </li>
          </ul>
        </div>
        <div class="hero__content--image">
          <?php  $hero_image = get_field('hero_image'); ?>
          <img src="<?php echo esc_url( $hero_image['url'] ); ?>" alt="Hero Image" />
        </div>
      </div>
      <div class="hero__clients">
        <div class="hero__clients--wrapper">
          <div class="hero__clients--right">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero/our-clients.png" alt="" />
            <h2><?php echo get_field('slider_heading') ?></h2>
          </div>
          <div class="hero__clients--logos">
            <ul class="slick-slider">
            <?php
            // Query to fetch 'logo_slider' posts
            $args = array(
                'post_type'      => 'logo_slider',
                'posts_per_page' => -1, 
                'order'          => 'ASC',
            );
            $logo_query = new WP_Query( $args );

            if ( $logo_query->have_posts() ) : ?>
                  <?php while ( $logo_query->have_posts() ) : $logo_query->the_post(); 
                  ?>
                  <?php $logo_image = get_field('Logo_image'); ?>
                  <li class="slick-slide">
                  <?php 
                    if($logo_image) : ?>
                      <img src="<?php echo esc_url( $logo_image['url'] ); ?>" 
                           alt="<?php echo esc_attr( $logo_image['alt'] ); ?>" 
                         title="<?php echo esc_attr( $logo_image['title'] ); ?>">
                    <?php endif; ?>
                  </li>
                  <?php endwhile; ?>
              <?php wp_reset_postdata(); ?>
              <?php else : ?>
                  <p>No logos found.</p>
              <?php endif; ?>
            </ul>
          </div>
          <div class="hero__clients--left">
            <a href="#"
              ><img src="<?php echo get_template_directory_uri(); ?>/assets/images/whatsapp.png" alt=""
            /></a>
          </div>
        </div>
      </div>
    </div>
  </section>
</section>
<script>
  jQuery(".slick-slider").slick({
    slidesToShow: 8,
    slidesToScroll: 8,
    arrows: false,
    dots: false,
    rtl: true,
    autoplay: true,
    autoplaySpeed: 3000,
    infinite: true,
    speed: 800,
    adaptiveHeight: false,
    responsive: [
    {
        breakpoint: 992,
        settings: {
        slidesToShow: 3,
        },
    },
    {
        breakpoint: 768,
        settings: {
        slidesToShow: 2,
        },
    },
    ],
});

function toggleMenu() {
    const menuIcon = document.querySelector(".toggle-menu");
    const navItems = document.querySelector(".nav-items");

    menuIcon.classList.toggle("open");
    navItems.classList.toggle("open");
}

</script>