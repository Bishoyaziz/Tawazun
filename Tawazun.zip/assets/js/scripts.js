jQuery(function(){
    jQuery(".slick-slider").slick({
        slidesToShow: 8,
        slidesToScroll: 8,
        arrows: false,
        dots: false,
        rtl: true,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true,
        speed: 800,
        adaptiveHeight: false,
        responsive: [
        {
            breakpoint: 992,
            settings: {
            slidesToShow: 3,
            },
        },
        {
            breakpoint: 768,
            settings: {
            slidesToShow: 2,
            },
        },
        ],
    });
});


function toggleMenu() {
    const menuIcon = document.querySelector(".toggle-menu");
    const navItems = document.querySelector(".nav-items");

    menuIcon.classList.toggle("open");
    navItems.classList.toggle("open");
}